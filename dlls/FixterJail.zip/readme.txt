Disclaimer: Yes, this is DOJ's jail script but it was written by myself so I am releasing this to the public.

Credits: Tom K. for UI design and implementation.

Installation: Simply drag and drop the FixterJail folder into your resources folder and start the resource.